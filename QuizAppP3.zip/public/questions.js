let currentQuestion = 0;
let score = 0;
let quizData = [];
let timerInterval;
const TIME_LIMIT = 15;

function loadQuestion() {
  clearInterval(timerInterval);

  const q = quizData[currentQuestion];
  if (!q) return;

  document.getElementById('question').innerText = decodeURIComponent(q.question);
  const optionsDiv = document.getElementById('options');
  optionsDiv.innerHTML = '';
  startTimer();

  const allAnswers = [...q.incorrect_answers, q.correct_answer];
  const shuffled = shuffleArray(allAnswers);

  shuffled.forEach(answer => {
    const btn = document.createElement('button');
    btn.classList.add('btn', 'btn-outline-warning', 'mb-2');
    btn.innerText = decodeURIComponent(answer);
    btn.onclick = () => {
      clearInterval(timerInterval);
      const isCorrect = answer === q.correct_answer;

      btn.classList.remove('btn-outline-warning');
      btn.classList.add(isCorrect ? 'correct' : 'wrong');

      if (isCorrect) score++;

      const allButtons = optionsDiv.querySelectorAll('button');
      allButtons.forEach(b => b.disabled = true);

      setTimeout(() => {
        currentQuestion++;
        if (currentQuestion < quizData.length) {
          loadQuestion();
        } else {
          localStorage.setItem('score', score);
          window.location.href = 'results.html';
        }
      }, 800);
    };
    optionsDiv.appendChild(btn);
  });
}

function startTimer() {
  let timeRemaining = TIME_LIMIT;
  const timerDisplay = document.getElementById('timer');
  timerDisplay.textContent = `Time: ${timeRemaining}`;

  timerInterval = setInterval(() => {
    timeRemaining--;
    timerDisplay.textContent = `Time: ${timeRemaining}`;
    if (timeRemaining <= 0) {
      clearInterval(timerInterval);
      currentQuestion++;
      if (currentQuestion < quizData.length) {
        loadQuestion();
      } else {
        localStorage.setItem('score', score);
        window.location.href = 'results.html';
      }
    }
  }, 1000);
}

async function loadQuizData() {
  try {
    const selectedCount = parseInt(localStorage.getItem('numQuestions')) || 10;
    const category = parseInt(localStorage.getItem('category')) || 18;
    const difficulty = "medium";

    const res = await fetch(`https://opentdb.com/api.php?amount=${selectedCount}&category=${category}&difficulty=${difficulty}&type=multiple`);
    const data = await res.json();
    quizData = data.results;
    loadQuestion();
  } catch (error) {
    console.error('Error loading questions:', error);
    document.getElementById('question').innerText = "Failed to load questions.";
  }
}

function shuffleArray(array) {
  return array.sort(() => Math.random() - 0.5);
}

window.onload = () => {};



